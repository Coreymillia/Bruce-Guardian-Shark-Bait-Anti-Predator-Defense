#include "core/mykeyboard.h"

void listenTcpPort();
void clientTCP();
