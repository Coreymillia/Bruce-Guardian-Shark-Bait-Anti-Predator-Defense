#ifndef __SERIAL_GPIO_CMD_H__
#define __SERIAL_GPIO_CMD_H__

#include <SimpleCLI.h>

void createGpioCommands(SimpleCLI *cli);

#endif

// gpio cmds https://docs.flipper.net/development/cli/#aqA4b
