#ifndef __SERIAL_IR_CMD_H__
#define __SERIAL_IR_CMD_H__

#include <SimpleCLI.h>

void createIrCommands(SimpleCLI *cli);

#endif
