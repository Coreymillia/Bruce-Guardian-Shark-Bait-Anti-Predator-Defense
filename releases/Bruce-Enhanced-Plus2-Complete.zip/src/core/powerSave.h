#include "display.h"
#include <globals.h>

void checkPowerSaveTime();

void sleepModeOn();

void sleepModeOff();

void fadeOutScreen(int startValue);
